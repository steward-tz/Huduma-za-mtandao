import PDFDocument from "pdfkit";
import QRCode from "qrcode";
import { tanzaniaEmblemBase64 } from "./tanzania-emblem";
import { peacockLogoBase64 } from "./peacock-logo";

export type LicensePdfData = {
  businessName: string;
  taxNumber: string;
  businessType: string;
  licenseType: string;
  principalBranch: string;
  region: string;
  district: string;
  ward: string;
  street: string;
  fee: string;
  issueDate: string;
  expiryDate: string;
  issuingOffice: string;
  licenseNumber: string;
};

const verificationBase = process.env.PUBLIC_APP_URL ?? "https://dawatihub-uvqlraqw.manus.space";

export async function createBusinessLicensePdf(data: LicensePdfData, reference: string, customTemplate?: Buffer) {
  const verificationUrl = `${verificationBase}/api/licenses/verify/${encodeURIComponent(reference)}`;
  const qr = await QRCode.toDataURL(verificationUrl, { errorCorrectionLevel: "H", margin: 1, width: 220 });
  const qrBuffer = Buffer.from(qr.split(",")[1], "base64");
  const emblem = Buffer.from(tanzaniaEmblemBase64.split(",")[1], "base64");
  const peacock = Buffer.from(peacockLogoBase64.split(",")[1], "base64");
  const doc = new PDFDocument({ size: "A4", margin: 0, info: { Title: `Business License ${data.licenseNumber}`, Author: "Huduma za mtandaoni" } });
  const chunks: Buffer[] = [];
  doc.on("data", (chunk: Buffer) => chunks.push(chunk));
  const done = new Promise<Buffer>((resolve, reject) => { doc.on("end", () => resolve(Buffer.concat(chunks))); doc.on("error", reject); });

  const navy = "#123a56";
  const green = "#087b3b";
  const pageLeft = 25;
  const pageTop = 25;
  const pageWidth = 545;
  const pageHeight = 790;
  const contentLeft = 62;
  const labelWidth = 132;
  const valueLeft = 205;
  const valueWidth = 272;

  doc.rect(pageLeft, pageTop, pageWidth, pageHeight).lineWidth(3).strokeColor("#167c9c").stroke();
  if (customTemplate?.length) {
    doc.save();
    doc.opacity(0.16);
    doc.image(customTemplate, 28, 28, { fit: [539, 784], align: "center", valign: "center" });
    doc.restore();
  }
  doc.save();
  doc.opacity(0.12);
  doc.image(emblem, 115, 270, { fit: [365, 365], align: "center" });
  doc.restore();

  // Fixed header bands prevent the emblem and headings from sharing a cursor position.
  doc.image(emblem, 268, 43, { fit: [60, 60], align: "center" });
  doc.fillColor("#18202a").font("Helvetica-Bold").fontSize(15).text("THE UNITED REPUBLIC OF TANZANIA", 50, 112, { width: 495, align: "center", lineBreak: false });
  doc.fontSize(16).text("BUSINESS LICENSE", 50, 139, { width: 495, align: "center", lineBreak: false });
  doc.fillColor(green).fontSize(10).text(`B.L. NO: ${data.licenseNumber}`, 50, 169, { width: 495, align: "center", lineBreak: false });
  doc.fillColor("#18202a").font("Helvetica").fontSize(8).text("The Business Licensing Act (Act No. 25 of 1972)", 50, 188, { width: 495, align: "center", lineBreak: false });

  let y = 232;
  const section = (title: string) => {
    doc.font("Helvetica-Bold").fontSize(11).fillColor(navy).text(title, contentLeft, y, { width: 450, lineBreak: false });
    y += 20;
  };
  const row = (label: string, content: string) => {
    doc.font("Helvetica").fontSize(8.5).fillColor("#36414b").text(label, contentLeft, y, { width: labelWidth, align: "right", lineBreak: false });
    doc.font("Helvetica-Bold").fontSize(8.5).fillColor("#18202a").text(content || "—", valueLeft, y, { width: valueWidth, lineBreak: false, ellipsis: true });
    y += 17;
  };

  section("License Details");
  row("Issuing Office:", data.issuingOffice);
  row("Tax Identification No:", data.taxNumber);
  row("License Issued To:", data.businessName);
  row("For the Business of:", data.businessType);
  row("Business Licensing:", data.licenseType);
  row("Date of Issue:", data.issueDate);
  row("Expiring Date:", data.expiryDate);
  row("Principal/Branch:", data.principalBranch);

  y += 12;
  section("Business Location");
  row("Region:", data.region);
  row("Ward:", data.ward);
  row("Street:", data.street);

  y += 12;
  section("Payment Details");
  row("Amount of Fee Paid:", Number(data.fee || 0).toLocaleString("en-TZ", { minimumFractionDigits: 2 }));

  doc.font("Helvetica").fontSize(8).fillColor("#18202a").text("This digital copy does not require a signature of authority", 50, 565, { width: 495, align: "center", lineBreak: false });

  const qrX = 405;
  const qrY = 390;
  doc.image(qrBuffer, qrX, qrY, { width: 120, height: 120 });
  doc.circle(qrX + 60, qrY + 60, 18).fillColor("#ffffff").fill();
  doc.image(peacock, qrX + 42, qrY + 42, { fit: [36, 36], align: "center" });
  doc.font("Helvetica").fontSize(7).fillColor("#52606c").text("Scan QR kuthibitisha leseni", qrX, qrY + 124, { width: 120, align: "center", lineBreak: false });

  doc.font("Helvetica-Bold").fontSize(8).fillColor("#18202a").text("CONDITIONS & NOTES:", contentLeft, 605, { width: 450, lineBreak: false });
  doc.font("Helvetica").fontSize(7).text("1. This license shall be conspicuously displayed at the place of business.\n2. Renewal applications must be submitted within 21 days of the license expiry; Otherwise, penalties begin at 25% of the license fee and rise by 2% for each additional month up to 47%.", contentLeft, 620, { width: 450, lineGap: 3 });
  doc.end();
  return { buffer: await done, verificationUrl };
}
