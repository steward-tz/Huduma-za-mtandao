import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { deleteService, deleteUserAccount, getActiveAnnouncement, getAdminStats, getAdminUserProfile, getAllTokenTransactions, getLicenseRecord, getLicenseRecords, getSiteSettings, getTokenHistory, getUserByOpenId, getUserNotifications, listAdminServices, listAllVideos, listServices, listVideos, searchAdminUsers, consumeService, adjustUserTokens, updateVerification, updateUserAccess, updateUserRole, updateAccountStatus, resetUserPassword, saveService, saveVideo, saveAnnouncement, saveSiteSettings, saveCertificateTemplate, clearCertificateTemplate } from "./db";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { LOCAL_SESSION_COOKIE, isValidPhone, localSessionMaxAge, loginLocalUser, normalizePhone, registerLocalUser } from "./auth-local";
import { createBusinessLicensePdf, type LicensePdfData } from "./license-pdf";
import { storageGetSignedUrl, storagePut } from "./storage";
import { isValidCertificateTemplate, MAX_CERTIFICATE_TEMPLATE_BYTES } from "./template-upload";

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin" || ctx.user.accountStatus !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "Admin aliyeidhinishwa pekee." });
  return next({ ctx });
});

function safeUser<T extends { passwordHash?: string | null; otpCode?: string | null; otpExpiresAt?: Date | null }>(user: T) {
  const { passwordHash: _passwordHash, otpCode: _otpCode, otpExpiresAt: _otpExpiresAt, ...publicUser } = user;
  return publicUser;
}

const procedureError = (error: unknown): never => {
  const message = error instanceof Error ? error.message : "UNKNOWN";
  const known: Record<string, { code: "BAD_REQUEST" | "PRECONDITION_FAILED" | "NOT_FOUND" | "FORBIDDEN"; message: string }> = {
    ACCOUNT_NOT_APPROVED: { code: "PRECONDITION_FAILED", message: "Akaunti yako haijaidhinishwa na admin." },
    ACCOUNT_INACTIVE: { code: "FORBIDDEN", message: "Akaunti yako haijawezeshwa. Wasiliana na admin." },
    INSUFFICIENT_TOKENS: { code: "BAD_REQUEST", message: "Huna tokeni za kutosha. Tafadhali nunua tokeni." },
    SERVICE_LOCKED: { code: "BAD_REQUEST", message: "Huduma hii imefungwa kwa sasa." },
    SERVICE_NOT_FOUND: { code: "NOT_FOUND", message: "Huduma haijapatikana." },
    CATEGORY_RESTRICTED: { code: "FORBIDDEN", message: "Akaunti yako haina ruhusa ya kutumia kundi hili la huduma." },
    INVALID_TOKEN_BALANCE: { code: "BAD_REQUEST", message: "Salio la tokeni haliwezi kuwa chini ya sifuri." },
  };
  const mapped = known[message];
  if (mapped) throw new TRPCError(mapped);
  throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Hitilafu imetokea. Jaribu tena." });
};

const phoneInput = z.string().trim().refine(isValidPhone, "Namba ya Tanzania si sahihi");
const colorInput = z.string().regex(/^#[0-9a-fA-F]{6}$/, "Tumia rangi ya HEX, mfano #7c5cff");
const siteSettingsInput = z.object({
  id: z.literal(1).default(1),
  siteName: z.string().trim().min(3).max(120),
  heroEyebrow: z.string().trim().min(3).max(160),
  heroTitle: z.string().trim().min(3).max(180),
  heroAccent: z.string().trim().min(3).max(180),
  heroDescription: z.string().trim().min(10).max(800),
  searchPlaceholder: z.string().trim().min(3).max(180),
  whatsappNumber: z.string().trim().regex(/^255\d{9}$/),
  footerCompany: z.string().trim().min(2).max(180),
  footerText: z.string().trim().min(3).max(255),
  primaryColor: colorInput,
  accentColor: colorInput,
});

async function getCertificateTemplateBuffer() {
  try {
    const settings = await getSiteSettings();
    if (!settings?.certificateTemplateKey || !settings.certificateTemplateMime || !["image/png", "image/jpeg"].includes(settings.certificateTemplateMime)) return undefined;
    const url = await storageGetSignedUrl(settings.certificateTemplateKey);
    const response = await fetch(url);
    if (!response.ok) return undefined;
    return Buffer.from(await response.arrayBuffer());
  } catch {
    return undefined;
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(async ({ ctx }) => {
      if (!ctx.user) return null;
      return safeUser((await getUserByOpenId(ctx.user.openId)) ?? ctx.user);
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      ctx.res.clearCookie(LOCAL_SESSION_COOKIE, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    register: publicProcedure.input(z.object({
      firstName: z.string().trim().min(2).max(80),
      lastName: z.string().trim().min(2).max(80),
      phone: phoneInput,
      password: z.string().min(6).max(128),
    })).mutation(async ({ ctx, input }) => {
      try {
        const result = await registerLocalUser(input);
        return { user: safeUser(result.user) };
      } catch (error) {
        const message = error instanceof Error ? error.message : "REGISTRATION_FAILED";
        if (message === "PHONE_EXISTS") throw new TRPCError({ code: "CONFLICT", message: "Namba hii tayari imesajiliwa. Tumia INGIA." });
        if (message === "INVALID_PHONE") throw new TRPCError({ code: "BAD_REQUEST", message: "Tumia namba kwa muundo wa +255698232313." });
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Usajili umeshindikana. Jaribu tena." });
      }
    }),
    login: publicProcedure.input(z.object({ phone: phoneInput, password: z.string().min(1).max(128) })).mutation(async ({ ctx, input }) => {
      try {
        const result = await loginLocalUser(input.phone, input.password);
        ctx.res.cookie(LOCAL_SESSION_COOKIE, result.token, { ...getSessionCookieOptions(ctx.req), maxAge: localSessionMaxAge() });
        return { user: safeUser(result.user) };
      } catch (error) {
        const message = error instanceof Error ? error.message : "INVALID_CREDENTIALS";
        if (message.startsWith("ACCOUNT_RESTRICTED:")) throw new TRPCError({ code: "FORBIDDEN", message: `Akaunti hii imezuiwa. Sababu: ${message.split(":").slice(1).join(":")}` });
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Namba au nywila si sahihi." });
      }
    }),
  }),
  catalog: router({
    services: publicProcedure.query(() => listServices()),
    videos: publicProcedure.query(() => listVideos()),
    announcement: publicProcedure.query(() => getActiveAnnouncement()),
    siteSettings: publicProcedure.query(() => getSiteSettings()),
  }),
  account: router({
    summary: protectedProcedure.query(async ({ ctx }) => {
      const user = await getUserByOpenId(ctx.user.openId);
      return safeUser(user ?? ctx.user);
    }),
    history: protectedProcedure.query(({ ctx }) => getTokenHistory(ctx.user.id)),
    notifications: protectedProcedure.query(({ ctx }) => getUserNotifications(ctx.user.id)),
    useService: protectedProcedure.input(z.object({ serviceId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      try {
        return await consumeService(ctx.user.id, input.serviceId);
      } catch (error) {
        return procedureError(error);
      }
    }),
    downloadBusinessLicense: protectedProcedure.input(z.object({ serviceId: z.number().int().positive(), license: z.object({ businessName: z.string().trim().min(2).max(180), taxNumber: z.string().trim().regex(/^\d{3}-\d{3}-\d{3}$/, "TIN itumie muundo 180-120-126"), businessType: z.string().trim().min(2).max(120), licenseType: z.enum(["NEW LICENSE", "RENEWED LICENSE"]), principalBranch: z.enum(["PRINCIPAL", "BRANCH"]), region: z.string().trim().min(2).max(80), district: z.string().trim().max(100), ward: z.string().trim().min(2).max(100), street: z.string().trim().min(2).max(180), fee: z.string().trim().min(1).max(30), issueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), expiryDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), issuingOffice: z.string().trim().min(2).max(120), licenseNumber: z.string().regex(/^BL01396922025-26000\d{5}$/) }) })).mutation(async ({ ctx, input }) => {
      try {
        const result = await consumeService(ctx.user.id, input.serviceId, JSON.stringify(input.license), "LESENI YA BIASHARA");
        const pdf = await createBusinessLicensePdf(input.license as LicensePdfData, result.reference, await getCertificateTemplateBuffer());
        return { filename: `${input.license.licenseNumber}.pdf`, reference: result.reference, balance: result.balance, pdfBase64: pdf.buffer.toString("base64"), verificationUrl: pdf.verificationUrl };
      } catch (error) {
        return procedureError(error);
      }
    }),
  }),
  admin: router({
    stats: adminProcedure.query(() => getAdminStats()),
    transactions: adminProcedure.query(() => getAllTokenTransactions()),
    licenseRecords: adminProcedure.query(() => getLicenseRecords()),
    downloadLicense: adminProcedure.input(z.object({ reference: z.string().trim().min(5).max(120) })).mutation(async ({ input }) => {
      const record = await getLicenseRecord(input.reference);
      if (!record) throw new TRPCError({ code: "NOT_FOUND", message: "Leseni haijapatikana." });
      const pdf = await createBusinessLicensePdf(record.data as LicensePdfData, record.reference, await getCertificateTemplateBuffer());
      return { filename: `${record.data.licenseNumber ?? record.reference}.pdf`, pdfBase64: pdf.buffer.toString("base64") };
    }),
    users: adminProcedure.input(z.object({ search: z.string().optional() }).optional()).query(async ({ input }) => (await searchAdminUsers(input?.search)).map(safeUser)),
    userProfile: adminProcedure.input(z.object({ userId: z.number().int().positive() })).query(async ({ input }) => { const profile = await getAdminUserProfile(input.userId); return profile ? { ...profile, user: safeUser(profile.user) } : null; }),
    updateUserStatus: adminProcedure.input(z.object({ userId: z.number().int().positive(), status: z.enum(["approved", "rejected", "blocked", "pending"]), reason: z.string().trim().max(255).optional() })).mutation(({ ctx, input }) => updateVerification(ctx.user.id, input.userId, input.status, input.reason)),
    updateUserRole: adminProcedure.input(z.object({ userId: z.number().int().positive(), role: z.enum(["user", "admin"]) })).mutation(({ ctx, input }) => updateUserRole(ctx.user.id, input.userId, input.role)),
    updateAccountStatus: adminProcedure.input(z.object({ userId: z.number().int().positive(), accountStatus: z.enum(["active", "inactive", "blocked"]) })).mutation(({ ctx, input }) => updateAccountStatus(ctx.user.id, input.userId, input.accountStatus)),
    resetUserPassword: adminProcedure.input(z.object({ userId: z.number().int().positive() })).mutation(({ ctx, input }) => resetUserPassword(ctx.user.id, input.userId)),
    deleteUser: adminProcedure.input(z.object({ userId: z.number().int().positive() })).mutation(({ ctx, input }) => deleteUserAccount(ctx.user.id, input.userId)),
    updateUserAccess: adminProcedure.input(z.object({ userId: z.number().int().positive(), categories: z.array(z.enum(["main", "tools", "locked"])).max(3) })).mutation(({ ctx, input }) => updateUserAccess(ctx.user.id, input.userId, input.categories)),
    adjustTokens: adminProcedure.input(z.object({ userId: z.number().int().positive(), amount: z.number().int().min(-100000).max(100000), description: z.string().trim().min(3).max(255) })).mutation(async ({ ctx, input }) => {
      try {
        return await adjustUserTokens(ctx.user.id, input.userId, input.amount, input.description);
      } catch (error) {
        return procedureError(error);
      }
    }),
    services: adminProcedure.query(() => listAdminServices()),
    saveService: adminProcedure.input(z.object({ id: z.number().int().positive().optional(), name: z.string().trim().min(2).max(180), description: z.string().trim().min(2).max(255), icon: z.string().trim().min(2).max(60), tokenCost: z.number().int().min(0).max(100), isFree: z.boolean(), isLocked: z.boolean(), isActive: z.boolean(), displayOrder: z.number().int().min(0).max(10000), category: z.string().trim().min(2).max(40), actionUrl: z.string().max(500).optional() })).mutation(({ ctx, input }) => saveService(input, ctx.user.id)),
    deleteService: adminProcedure.input(z.object({ serviceId: z.number().int().positive() })).mutation(({ ctx, input }) => deleteService(input.serviceId, ctx.user.id)),
    videos: adminProcedure.query(async () => listAllVideos()),
    saveVideo: adminProcedure.input(z.object({ id: z.number().int().positive().optional(), title: z.string().trim().min(2).max(180), description: z.string().trim().min(2).max(255), url: z.string().max(1000), tokenCost: z.number().int().min(0).max(100), isActive: z.boolean() })).mutation(({ ctx, input }) => saveVideo(input, ctx.user.id)),
    saveAnnouncement: adminProcedure.input(z.object({ message: z.string().trim().min(10).max(800) })).mutation(({ ctx, input }) => saveAnnouncement(input.message, ctx.user.id)),
    siteSettings: adminProcedure.query(() => getSiteSettings()),
    saveSiteSettings: adminProcedure.input(siteSettingsInput).mutation(({ ctx, input }) => saveSiteSettings(input, ctx.user.id)),
    uploadCertificateTemplate: adminProcedure.input(z.object({
      filename: z.string().trim().min(1).max(180),
      contentType: z.enum(["image/png", "image/jpeg"]),
      base64: z.string().min(20).max(12_000_000),
    })).mutation(async ({ ctx, input }) => {
      const buffer = Buffer.from(input.base64.replace(/^data:[^;]+;base64,/, ""), "base64");
      if (buffer.length > MAX_CERTIFICATE_TEMPLATE_BYTES) throw new TRPCError({ code: "BAD_REQUEST", message: "Picha iwe chini ya MB 8." });
      if (!isValidCertificateTemplate(buffer, input.contentType)) throw new TRPCError({ code: "BAD_REQUEST", message: "Faili si picha halali." });
      const extension = input.contentType === "image/png" ? "png" : "jpg";
      const stored = await storagePut(`certificate-templates/template-${Date.now()}.${extension}`, buffer, input.contentType);
      return saveCertificateTemplate({ key: stored.key, url: stored.url, mime: input.contentType }, ctx.user.id);
    }),
    clearCertificateTemplate: adminProcedure.mutation(({ ctx }) => clearCertificateTemplate(ctx.user.id)),
  }),
});

export type AppRouter = typeof appRouter;
