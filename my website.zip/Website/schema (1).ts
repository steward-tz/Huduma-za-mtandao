import {
  bigint,
  boolean,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

/** Auth identity and application profile. Manus OAuth owns credentials; app fields own approval and tokens. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  fullName: varchar("fullName", { length: 160 }),
  phone: varchar("phone", { length: 40 }).unique(),
  email: varchar("email", { length: 320 }),
  passwordHash: varchar("passwordHash", { length: 255 }),
  otpCode: varchar("otpCode", { length: 10 }),
  otpExpiresAt: timestamp("otpExpiresAt"),
  otpVerified: boolean("otpVerified").default(true).notNull(),
  restrictionReason: text("restrictionReason"),
  allowedCategories: text("allowedCategories"),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  accountStatus: mysqlEnum("accountStatus", ["active", "inactive", "blocked"]).default("active").notNull(),
  verificationStatus: mysqlEnum("verificationStatus", ["pending", "approved", "rejected", "blocked"])
    .default("pending")
    .notNull(),
  tokenBalance: int("tokenBalance").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const services = mysqlTable("services", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 180 }).notNull(),
  description: varchar("description", { length: 255 }).notNull(),
  icon: varchar("icon", { length: 60 }).notNull(),
  tokenCost: int("tokenCost").default(0).notNull(),
  isFree: boolean("isFree").default(false).notNull(),
  isLocked: boolean("isLocked").default(false).notNull(),
  category: varchar("category", { length: 40 }).default("main").notNull(),
  actionUrl: text("actionUrl"),
  displayOrder: int("displayOrder").default(0).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
  updatedAt: bigint("updatedAt", { mode: "number" }).notNull(),
});

export const tokenTransactions = mysqlTable("tokenTransactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["credit", "debit", "adjustment"]).notNull(),
  amount: int("amount").notNull(),
  serviceId: int("serviceId"),
  serviceName: varchar("serviceName", { length: 180 }),
  description: varchar("description", { length: 255 }).notNull(),
  metadata: text("metadata"),
  reference: varchar("reference", { length: 120 }).notNull(),
  previousBalance: int("previousBalance").default(0).notNull(),
  balanceAfter: int("balanceAfter").notNull(),
  adminUserId: int("adminUserId"),
  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
});

export const serviceUsage = mysqlTable("serviceUsage", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  serviceId: int("serviceId").notNull(),
  serviceName: varchar("serviceName", { length: 180 }),
  tokensUsed: int("tokensUsed").notNull(),
  previousBalance: int("previousBalance").default(0).notNull(),
  newBalance: int("newBalance").default(0).notNull(),
  reference: varchar("reference", { length: 120 }).notNull(),
  metadata: text("metadata"),
  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
});

export const tutorialVideos = mysqlTable("tutorialVideos", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 180 }).notNull(),
  description: varchar("description", { length: 255 }).notNull(),
  url: text("url").notNull(),
  tokenCost: int("tokenCost").default(2).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
  updatedAt: bigint("updatedAt", { mode: "number" }).notNull(),
});

export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 160 }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
});

export const announcements = mysqlTable("announcements", {
  id: int("id").autoincrement().primaryKey(),
  message: text("message").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
  updatedAt: bigint("updatedAt", { mode: "number" }).notNull(),
});

export const adminActions = mysqlTable("adminActions", {
  id: int("id").autoincrement().primaryKey(),
  adminUserId: int("adminUserId").notNull(),
  action: varchar("action", { length: 120 }).notNull(),
  targetUserId: int("targetUserId"),
  metadata: text("metadata"),
  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
});

export const siteSettings = mysqlTable("siteSettings", {
  id: int("id").primaryKey(),
  siteName: varchar("siteName", { length: 120 }).default("Huduma za mtandaoni").notNull(),
  heroEyebrow: varchar("heroEyebrow", { length: 160 }).default("Kituo chako cha kidigitali").notNull(),
  heroTitle: varchar("heroTitle", { length: 180 }).default("Huduma rahisi.").notNull(),
  heroAccent: varchar("heroAccent", { length: 180 }).default("Matokeo ya haraka.").notNull(),
  heroDescription: text("heroDescription").notNull(),
  searchPlaceholder: varchar("searchPlaceholder", { length: 180 }).default("Tafuta huduma au zana...").notNull(),
  whatsappNumber: varchar("whatsappNumber", { length: 30 }).default("255698232313").notNull(),
  footerCompany: varchar("footerCompany", { length: 180 }).default("Bw. Zoom Cotex Limited").notNull(),
  footerText: varchar("footerText", { length: 255 }).default("Haki zote zimehifadhiwa 2026").notNull(),
  primaryColor: varchar("primaryColor", { length: 20 }).default("#7c5cff").notNull(),
  accentColor: varchar("accentColor", { length: 20 }).default("#22d3ee").notNull(),
  certificateTemplateKey: text("certificateTemplateKey"),
  certificateTemplateUrl: text("certificateTemplateUrl"),
  certificateTemplateMime: varchar("certificateTemplateMime", { length: 80 }),
  updatedBy: int("updatedBy"),
  updatedAt: bigint("updatedAt", { mode: "number" }).notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Service = typeof services.$inferSelect;
export type TutorialVideo = typeof tutorialVideos.$inferSelect;
export type TokenTransaction = typeof tokenTransactions.$inferSelect;
export type SiteSettings = typeof siteSettings.$inferSelect;
