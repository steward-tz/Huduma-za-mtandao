import { and, asc, desc, eq, gte, like, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  adminActions,
  announcements,
  InsertUser,
  notifications,
  serviceUsage,
  services,
  siteSettings,
  tokenTransactions,
  tutorialVideos,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  if (user.name !== undefined) {
    values.name = user.name ?? null;
    updateSet.name = values.name;
  }
  if (user.email !== undefined) {
    values.email = user.email ?? null;
    updateSet.email = values.email;
  }
  if (user.loginMethod !== undefined) {
    values.loginMethod = user.loginMethod ?? null;
    updateSet.loginMethod = values.loginMethod;
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  } else {
    values.lastSignedIn = new Date();
    updateSet.lastSignedIn = values.lastSignedIn;
  }
  if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    values.verificationStatus = "approved";
    updateSet.role = "admin";
    updateSet.verificationStatus = "approved";
  }

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

const now = () => Date.now();

export const DEFAULT_SITE_SETTINGS = {
  id: 1,
  siteName: "Huduma za mtandaoni",
  heroEyebrow: "Kituo chako cha kidigitali",
  heroTitle: "Huduma rahisi.",
  heroAccent: "Matokeo ya haraka.",
  heroDescription: "Huduma muhimu, zana za biashara na nyaraka za kidigitali katika sehemu moja iliyo salama na rahisi kutumia.",
  searchPlaceholder: "Tafuta huduma au zana...",
  whatsappNumber: "255698232313",
  footerCompany: "Bw. Zoom Cotex Limited",
  footerText: "Haki zote zimehifadhiwa 2026",
  primaryColor: "#7c5cff",
  accentColor: "#22d3ee",
};

const DEFAULT_SERVICES = [
  ["CHETI CHA TIN", "Pakua cheti cha TIN", "FileText", 2, false, "main"],
  ["THIBITISHA TIN", "Thibitisha taarifa za TIN", "BadgeCheck", 2, false, "main"],
  ["NAKALA LAINI YA NIDA", "Omba nakala laini ya NIDA", "IdCard", 2, false, "main"],
  ["STIKA ZA LIPA", "Huduma za stika za LIPA", "CreditCard", 2, false, "main"],
  ["MPIGA KURA", "Huduma ya taarifa za mpiga kura", "Vote", 2, false, "main"],
  ["LESENI YA BIASHARA", "Msaada wa leseni ya biashara", "Store", 2, false, "main"],
  ["STIKA ZA MAWAKALA", "Stika za mawakala", "BadgePercent", 2, false, "main"],
  ["NAKALA LAINI YA NIDA 2", "Huduma mbadala ya nakala NIDA", "Copy", 2, false, "main"],
  ["LESENI YA UDEREVA", "Msaada wa leseni ya udereva", "CarFront", 2, false, "main"],
  ["UTAFUTA WA NIDA", "Tafuta taarifa ya NIDA", "Search", 0, true, "main"],
  ["MSIMBO WA QR MITANDAO YOTE", "Tengeneza QR ya mitandao yote", "QrCode", 0, true, "main"],
  ["BRELA", "Huduma za BRELA", "Building2", 2, false, "main"],
  ["TENGENEZA MUZIKI", "Tengeneza muziki wa ubunifu", "Music2", 2, false, "tools"],
  ["TAFUTA KVAR PICHA", "Tafuta picha kwa maelezo", "Image", 2, false, "tools"],
  ["SIMU YA TAFUTA", "Tafuta taarifa ya simu", "Smartphone", 2, false, "tools"],
  ["USULI WA ONDOA", "Ondoa usuli wa picha", "Eraser", 2, false, "tools"],
  ["WASIFU WA CHONGA", "Chonga wasifu wa kisasa", "UserRound", 2, false, "tools"],
  ["NEMBO YA CHONGA", "Chonga nembo ya biashara", "PenTool", 2, false, "tools"],
  ["RADIO MARIA", "Fungua Radio Maria", "Radio", 2, false, "tools"],
  ["SIMBA SC", "Huduma za Simba SC", "Trophy", 2, false, "tools"],
  ["YANGA AFRICANS", "Huduma za Yanga Africans", "Shield", 2, false, "tools"],
  ["AZAM TV", "Huduma za Azam TV", "Tv", 2, false, "tools"],
  ["CHETI CHA KUZALIWA", "Huduma haipatikani kwa sasa", "Baby", 0, false, "locked"],
  ["VISA / PASIPOTI", "Huduma haipatikani kwa sasa", "Plane", 0, false, "locked"],
  ["CHETI CHA NDOA", "Huduma haipatikani kwa sasa", "Heart", 0, false, "locked"],
  ["RIPOTI YA HASARA", "Huduma haipatikani kwa sasa", "FileWarning", 0, false, "locked"],
] as const;

async function ensureInitialAdmin(db: Awaited<ReturnType<typeof getDb>>) {
  if (!db) return;
  const phone = "+255698232313";
  const existing = (await db.select().from(users).where(eq(users.phone, phone)).limit(1))[0];
  if (existing) {
    if (existing.role !== "admin" || existing.accountStatus !== "active" || existing.verificationStatus !== "approved") {
      await db.update(users).set({ role: "admin", accountStatus: "active", verificationStatus: "approved" }).where(eq(users.id, existing.id));
    }
    return;
  }
  const { hashPassword } = await import("./auth-local");
  await db.insert(users).values({ openId: `local:${phone}`, name: "Huduma za mtandaoni Admin", fullName: "Huduma za mtandaoni Admin", phone, passwordHash: hashPassword(process.env.ADMIN_INITIAL_PASSWORD || "Steward@999"), loginMethod: "phone", role: "admin", accountStatus: "active", verificationStatus: "approved", otpVerified: true, tokenBalance: 0, lastSignedIn: new Date() });
}

export async function ensureInitialAdminAccount() {
  const db = await getDb();
  if (db) await ensureInitialAdmin(db);
}

export async function ensureSeedData() {
  const db = await getDb();
  if (!db) return;
  await ensureInitialAdmin(db);
  const existing = await db.select({ id: services.id }).from(services).limit(1);
  if (existing.length === 0) {
    const timestamp = now();
    await db.insert(services).values(
      DEFAULT_SERVICES.map(([name, description, icon, tokenCost, isFree, category], index) => ({
        name,
        description,
        icon,
        tokenCost,
        isFree,
        isLocked: category === "locked",
        isActive: true,
        displayOrder: index + 1,
        category,
        createdAt: timestamp,
        updatedAt: timestamp,
      })),
    );
  }
  const videos = await db.select({ id: tutorialVideos.id }).from(tutorialVideos).limit(1);
  if (videos.length === 0) {
    const timestamp = now();
    await db.insert(tutorialVideos).values([
      { title: "KUSAJILI LIPA NAMBA VODACOM", description: "Jifunze hatua za kusajili Lipa Namba.", url: "", tokenCost: 2, isActive: true, createdAt: timestamp, updatedAt: timestamp },
      { title: "JINSI YA KUDOWNLOAD TIN", description: "Mwongozo wa kupakua TIN yako.", url: "", tokenCost: 2, isActive: true, createdAt: timestamp, updatedAt: timestamp },
      { title: "KUOMBA TIN MTEJA MPYA", description: "Hatua za kumuombea mteja mpya TIN.", url: "", tokenCost: 2, isActive: true, createdAt: timestamp, updatedAt: timestamp },
    ]);
  }
  const activeAnnouncement = await db.select({ id: announcements.id }).from(announcements).where(eq(announcements.isActive, true)).limit(1);
  if (activeAnnouncement.length === 0) {
    const timestamp = now();
    await db.insert(announcements).values({
      message: "JIPATIE TOKENI KUPITIA NAMBA +255698232313 · Huduma za mtandaoni · UKILIPIA UNAPA TOKENI · LIPIA UKIMALIZA NIFOWADIE MESEJI YA MWAMALA",
      isActive: true,
      createdAt: timestamp,
      updatedAt: timestamp,
    });
  }
  await db.insert(siteSettings).values({ ...DEFAULT_SITE_SETTINGS, updatedAt: now() }).onDuplicateKeyUpdate({ set: { id: 1 } });
}

export async function listServices() {
  const db = await getDb();
  if (!db) return [];
  await ensureSeedData();
  const rows = await db.select().from(services).where(eq(services.isActive, true)).orderBy(asc(services.displayOrder), asc(services.id));
  return rows.filter((service, index) => rows.findIndex((candidate) => candidate.name === service.name) === index);
}

export async function listVideos() {
  const db = await getDb();
  if (!db) return [];
  await ensureSeedData();
  const rows = await db.select().from(tutorialVideos).where(eq(tutorialVideos.isActive, true)).orderBy(asc(tutorialVideos.id));
  return rows.filter((video, index) => rows.findIndex((candidate) => candidate.title === video.title) === index);
}

export async function listAllVideos() {
  const db = await getDb();
  if (!db) return [];
  await ensureSeedData();
  const rows = await db.select().from(tutorialVideos).orderBy(asc(tutorialVideos.id));
  return rows.filter((video, index) => rows.findIndex((candidate) => candidate.title === video.title) === index);
}

export async function getActiveAnnouncement() {
  const db = await getDb();
  if (!db) return undefined;
  await ensureSeedData();
  const rows = await db.select().from(announcements).where(eq(announcements.isActive, true)).orderBy(desc(announcements.id)).limit(1);
  return rows[0];
}

export async function getSiteSettings() {
  const db = await getDb();
  if (!db) return { ...DEFAULT_SITE_SETTINGS, certificateTemplateKey: null, certificateTemplateUrl: null, certificateTemplateMime: null, updatedBy: null, updatedAt: now() };
  await ensureSeedData();
  return (await db.select().from(siteSettings).where(eq(siteSettings.id, 1)).limit(1))[0];
}

export async function saveSiteSettings(input: typeof DEFAULT_SITE_SETTINGS, adminId: number) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const timestamp = now();
  const values = { ...input, id: 1, updatedBy: adminId, updatedAt: timestamp };
  await db.insert(siteSettings).values(values).onDuplicateKeyUpdate({ set: values });
  await db.insert(adminActions).values({ adminUserId: adminId, action: "UPDATE_SITE_SETTINGS", metadata: JSON.stringify(input), createdAt: timestamp });
  return getSiteSettings();
}

export async function saveCertificateTemplate(input: { key: string; url: string; mime: string }, adminId: number) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const timestamp = now();
  await db.insert(siteSettings).values({ ...DEFAULT_SITE_SETTINGS, id: 1, certificateTemplateKey: input.key, certificateTemplateUrl: input.url, certificateTemplateMime: input.mime, updatedBy: adminId, updatedAt: timestamp }).onDuplicateKeyUpdate({ set: { certificateTemplateKey: input.key, certificateTemplateUrl: input.url, certificateTemplateMime: input.mime, updatedBy: adminId, updatedAt: timestamp } });
  await db.insert(adminActions).values({ adminUserId: adminId, action: "REPLACE_CERTIFICATE_TEMPLATE", metadata: JSON.stringify({ key: input.key, mime: input.mime }), createdAt: timestamp });
  return getSiteSettings();
}

export async function clearCertificateTemplate(adminId: number) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const timestamp = now();
  await db.update(siteSettings).set({ certificateTemplateKey: null, certificateTemplateUrl: null, certificateTemplateMime: null, updatedBy: adminId, updatedAt: timestamp }).where(eq(siteSettings.id, 1));
  await db.insert(adminActions).values({ adminUserId: adminId, action: "RESET_CERTIFICATE_TEMPLATE", createdAt: timestamp });
  return getSiteSettings();
}

export async function getTokenHistory(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: tokenTransactions.id,
    type: tokenTransactions.type,
    amount: tokenTransactions.amount,
    serviceName: tokenTransactions.serviceName,
    description: tokenTransactions.description,
    reference: tokenTransactions.reference,
    previousBalance: tokenTransactions.previousBalance,
    balanceAfter: tokenTransactions.balanceAfter,
    adminUserId: tokenTransactions.adminUserId,
    createdAt: tokenTransactions.createdAt,
  }).from(tokenTransactions).where(eq(tokenTransactions.userId, userId)).orderBy(desc(tokenTransactions.id)).limit(100);
}

export async function getUserNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.id)).limit(30);
}

export async function consumeService(userId: number, serviceId: number, metadata?: string, expectedServiceName?: string) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const serviceRows = await db.select().from(services).where(eq(services.id, serviceId)).limit(1);
  const service = serviceRows[0];
  if (!service) throw new Error("SERVICE_NOT_FOUND");
  if (expectedServiceName && !service.name.toUpperCase().includes(expectedServiceName.toUpperCase())) throw new Error("SERVICE_NOT_FOUND");
  if (service.isLocked) throw new Error("SERVICE_LOCKED");

  const userRows = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  const user = userRows[0];
  if (!user) throw new Error("USER_NOT_FOUND");
  if (user.verificationStatus !== "approved") throw new Error("ACCOUNT_NOT_APPROVED");
  if (user.accountStatus !== "active") throw new Error("ACCOUNT_INACTIVE");
  if (user.allowedCategories) {
    const allowed = JSON.parse(user.allowedCategories) as string[];
    if (!allowed.includes(service.category)) throw new Error("CATEGORY_RESTRICTED");
  }

  const reference = `SV-${Date.now()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
  const cost = service.isFree ? 0 : service.tokenCost;
  let balance = user.tokenBalance;
  if (cost > 0) {
    const updated = await db.update(users)
      .set({ tokenBalance: sql`${users.tokenBalance} - ${cost}` })
      .where(and(eq(users.id, userId), gte(users.tokenBalance, cost), eq(users.verificationStatus, "approved"), eq(users.accountStatus, "active")));
    if (updated[0].affectedRows !== 1) throw new Error("INSUFFICIENT_TOKENS");
    const after = await db.select({ tokenBalance: users.tokenBalance }).from(users).where(eq(users.id, userId)).limit(1);
    balance = after[0]?.tokenBalance ?? Math.max(0, user.tokenBalance - cost);
    await db.insert(tokenTransactions).values({ userId, type: "debit", amount: -cost, serviceId, serviceName: service.name, description: service.name, metadata: metadata ?? null, reference, previousBalance: user.tokenBalance, balanceAfter: balance, createdAt: now() });
    await db.insert(notifications).values({ userId, title: "Tokeni zimetumika", message: `Umetumia tokeni ${cost} kwenye ${service.name}.`, isRead: false, createdAt: now() });
  }
  await db.insert(serviceUsage).values({ userId, serviceId, serviceName: service.name, tokensUsed: cost, reference, previousBalance: user.tokenBalance, newBalance: balance, metadata: metadata ?? null, createdAt: now() });
  return { service, balance, reference };
}

export async function getLicenseRecord(reference: string) {
  const db = await getDb();
  if (!db) return null;
  const row = (await db.select({ userId: tokenTransactions.userId, reference: tokenTransactions.reference, metadata: tokenTransactions.metadata, serviceName: tokenTransactions.serviceName, createdAt: tokenTransactions.createdAt }).from(tokenTransactions).where(eq(tokenTransactions.reference, reference)).limit(1))[0];
  if (!row || !row.serviceName?.toUpperCase().includes("LESENI YA BIASHARA") || !row.metadata) return null;
  try { return { ...row, data: JSON.parse(row.metadata) as Record<string, string> }; } catch { return null; }
}

export async function getLicenseRecords() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select({ userId: tokenTransactions.userId, reference: tokenTransactions.reference, metadata: tokenTransactions.metadata, serviceName: tokenTransactions.serviceName, amount: tokenTransactions.amount, createdAt: tokenTransactions.createdAt }).from(tokenTransactions).where(like(tokenTransactions.serviceName, "%LESENI YA BIASHARA%")).orderBy(desc(tokenTransactions.id)).limit(200);
  return rows.map((row) => { try { return { ...row, data: row.metadata ? JSON.parse(row.metadata) as Record<string, string> : null }; } catch { return { ...row, data: null }; } }).filter((row) => row.data);
}

export async function searchAdminUsers(search?: string) {
  const db = await getDb();
  if (!db) return [];
  let rows;
  if (search?.trim()) {
    const term = `%${search.trim()}%`;
    rows = await db.select().from(users).where(sql`${users.name} LIKE ${term} OR ${users.fullName} LIKE ${term} OR ${users.phone} LIKE ${term} OR ${users.email} LIKE ${term}`).orderBy(desc(users.id)).limit(100);
  } else {
    rows = await db.select().from(users).orderBy(desc(users.id)).limit(100);
  }
  return Promise.all(rows.map(async (user) => ({ ...user, ...(await getUserTokenSummary(user.id)) })));
}

export async function getUserTokenSummary(userId: number) {
  const db = await getDb();
  if (!db) return { totalReceived: 0, totalUsed: 0 };
  const rows = await db.select().from(tokenTransactions).where(eq(tokenTransactions.userId, userId));
  return { totalReceived: rows.filter((row) => row.amount > 0).reduce((sum, row) => sum + row.amount, 0), totalUsed: rows.filter((row) => row.amount < 0).reduce((sum, row) => sum + Math.abs(row.amount), 0) };
}

export async function getAdminUserProfile(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const user = (await db.select().from(users).where(eq(users.id, userId)).limit(1))[0];
  if (!user) return null;
  const [tokenSummary, usage, history] = await Promise.all([getUserTokenSummary(userId), db.select().from(serviceUsage).where(eq(serviceUsage.userId, userId)).orderBy(desc(serviceUsage.id)), getTokenHistory(userId)]);
  return { user, tokenSummary, usage, history };
}

export async function getAdminStats() {
  const db = await getDb();
  if (!db) return { totalUsers: 0, activeUsers: 0, pendingUsers: 0, approvedUsers: 0, adminUsers: 0, totalTokensIssued: 0, totalTokensUsed: 0, totalTokensRemaining: 0, totalServiceUsage: 0 };
  const allUsers = await db.select().from(users);
  const transactions = await db.select().from(tokenTransactions);
  const usage = await db.select().from(serviceUsage);
  return {
    totalUsers: allUsers.length,
    activeUsers: allUsers.filter((u) => u.accountStatus === "active").length,
    pendingUsers: allUsers.filter((u) => u.verificationStatus === "pending").length,
    approvedUsers: allUsers.filter((u) => u.verificationStatus === "approved").length,
    adminUsers: allUsers.filter((u) => u.role === "admin").length,
    totalTokensIssued: transactions.filter((t) => t.amount > 0).reduce((sum, t) => sum + t.amount, 0),
    totalTokensUsed: transactions.filter((t) => t.amount < 0).reduce((sum, t) => sum + Math.abs(t.amount), 0),
    totalTokensRemaining: allUsers.reduce((sum, u) => sum + u.tokenBalance, 0),
    totalServiceUsage: usage.length,
  };
}

export async function getAllTokenTransactions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(tokenTransactions).orderBy(desc(tokenTransactions.id)).limit(200);
}

export async function adjustUserTokens(adminId: number, userId: number, amount: number, description: string) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const changed = await db.update(users).set({ tokenBalance: sql`${users.tokenBalance} + ${amount}` }).where(and(eq(users.id, userId), sql`${users.tokenBalance} + ${amount} >= 0`));
  if (changed[0].affectedRows !== 1) throw new Error("INVALID_TOKEN_BALANCE");
  const row = (await db.select({ tokenBalance: users.tokenBalance }).from(users).where(eq(users.id, userId)).limit(1))[0];
  const balance = row?.tokenBalance ?? 0;
  const reference = `ADJ-${Date.now()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
  await db.insert(tokenTransactions).values({ userId, type: amount >= 0 ? "credit" : "adjustment", amount, description, reference, previousBalance: balance - amount, balanceAfter: balance, adminUserId: adminId, createdAt: now() });
  await db.insert(adminActions).values({ adminUserId: adminId, action: amount >= 0 ? "ADD_TOKENS" : "REMOVE_TOKENS", targetUserId: userId, metadata: JSON.stringify({ amount, description }), createdAt: now() });
  await db.insert(notifications).values({ userId, title: amount >= 0 ? "Tokeni zimeongezwa" : "Tokeni zimepunguzwa", message: `${amount >= 0 ? "Umeongezewa" : "Umeondolewa"} tokeni ${Math.abs(amount)}.`, isRead: false, createdAt: now() });
  return { balance };
}

export async function updateVerification(adminId: number, userId: number, status: "approved" | "rejected" | "blocked" | "pending", reason?: string) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const cleanReason = reason?.trim() || null;
  await db.update(users).set({ verificationStatus: status, accountStatus: status === "blocked" ? "blocked" : status === "approved" ? "active" : undefined, restrictionReason: status === "approved" || status === "pending" ? null : cleanReason }).where(eq(users.id, userId));
  await db.insert(adminActions).values({ adminUserId: adminId, action: `STATUS_${status.toUpperCase()}`, targetUserId: userId, metadata: JSON.stringify({ reason: cleanReason }), createdAt: now() });
  await db.insert(notifications).values({ userId, title: "Hali ya akaunti imebadilika", message: `${status === "approved" ? "Akaunti yako imeidhinishwa" : `Akaunti yako sasa iko: ${status}${cleanReason ? ` — Sababu: ${cleanReason}` : ""}`}.`, isRead: false, createdAt: now() });
  return { status };
}

export async function updateUserRole(adminId: number, userId: number, role: "user" | "admin") {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  if (adminId === userId && role === "user") throw new Error("CANNOT_DEMOTE_SELF");
  await db.update(users).set({ role }).where(eq(users.id, userId));
  await db.insert(adminActions).values({ adminUserId: adminId, action: role === "admin" ? "PROMOTE_ADMIN" : "REMOVE_ADMIN", targetUserId: userId, createdAt: now() });
  return { role };
}

export async function updateAccountStatus(adminId: number, userId: number, accountStatus: "active" | "inactive" | "blocked") {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  if (adminId === userId && accountStatus !== "active") throw new Error("CANNOT_DISABLE_SELF");
  const current = (await db.select({ verificationStatus: users.verificationStatus }).from(users).where(eq(users.id, userId)).limit(1))[0];
  await db.update(users).set({ accountStatus, verificationStatus: accountStatus === "active" && current?.verificationStatus === "blocked" ? "pending" : undefined }).where(eq(users.id, userId));
  await db.insert(adminActions).values({ adminUserId: adminId, action: `ACCOUNT_${accountStatus.toUpperCase()}`, targetUserId: userId, createdAt: now() });
  return { accountStatus };
}

export async function resetUserPassword(adminId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const { hashPassword } = await import("./auth-local");
  await db.update(users).set({ passwordHash: hashPassword("123123") }).where(eq(users.id, userId));
  await db.insert(adminActions).values({ adminUserId: adminId, action: "RESET_PASSWORD", targetUserId: userId, metadata: JSON.stringify({ reset: true }), createdAt: now() });
  return { success: true };
}

export async function deleteUserAccount(adminId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  if (adminId === userId) throw new Error("CANNOT_DELETE_SELF");
  await db.delete(users).where(eq(users.id, userId));
  await db.insert(adminActions).values({ adminUserId: adminId, action: "DELETE_USER", targetUserId: userId, createdAt: now() });
  return { success: true };
}

export async function updateUserAccess(adminId: number, userId: number, categories: string[]) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  await db.update(users).set({ allowedCategories: categories.length ? JSON.stringify(categories) : null }).where(eq(users.id, userId));
  await db.insert(adminActions).values({ adminUserId: adminId, action: "UPDATE_USER_ACCESS", targetUserId: userId, metadata: JSON.stringify({ categories }), createdAt: now() });
  return { categories };
}

export async function listAdminServices() {
  const db = await getDb();
  if (!db) return [];
  await ensureSeedData();
  const rows = await db.select().from(services).orderBy(asc(services.displayOrder), asc(services.id));
  return rows.filter((service, index) => rows.findIndex((candidate) => candidate.name === service.name) === index);
}

export async function saveService(input: { id?: number; name: string; description: string; icon: string; tokenCost: number; isFree: boolean; isLocked: boolean; isActive: boolean; displayOrder: number; category: string; actionUrl?: string }, adminId: number) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const timestamp = now();
  if (input.id) {
    await db.update(services).set({ name: input.name, description: input.description, icon: input.icon, tokenCost: input.tokenCost, isFree: input.isFree, isLocked: input.isLocked, isActive: input.isActive, displayOrder: input.displayOrder, category: input.category, actionUrl: input.actionUrl || null, updatedAt: timestamp }).where(eq(services.id, input.id));
  } else {
    await db.insert(services).values({ name: input.name, description: input.description, icon: input.icon, tokenCost: input.tokenCost, isFree: input.isFree, isLocked: input.isLocked, isActive: input.isActive, displayOrder: input.displayOrder, category: input.category, actionUrl: input.actionUrl || null, createdAt: timestamp, updatedAt: timestamp });
  }
  await db.insert(adminActions).values({ adminUserId: adminId, action: input.id ? "EDIT_SERVICE" : "ADD_SERVICE", metadata: JSON.stringify(input), createdAt: timestamp });
  return { success: true };
}

export async function deleteService(serviceId: number, adminId: number) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  await db.delete(services).where(eq(services.id, serviceId));
  await db.insert(adminActions).values({ adminUserId: adminId, action: "DELETE_SERVICE", metadata: JSON.stringify({ serviceId }), createdAt: now() });
  return { success: true };
}

export async function saveVideo(input: { id?: number; title: string; description: string; url: string; tokenCost: number; isActive: boolean }, adminId: number) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const timestamp = now();
  if (input.id) {
    await db.update(tutorialVideos).set({ title: input.title, description: input.description, url: input.url, tokenCost: input.tokenCost, isActive: input.isActive, updatedAt: timestamp }).where(eq(tutorialVideos.id, input.id));
  } else {
    await db.insert(tutorialVideos).values({ title: input.title, description: input.description, url: input.url, tokenCost: input.tokenCost, isActive: input.isActive, createdAt: timestamp, updatedAt: timestamp });
  }
  await db.insert(adminActions).values({ adminUserId: adminId, action: input.id ? "EDIT_VIDEO" : "ADD_VIDEO", metadata: JSON.stringify(input), createdAt: timestamp });
  return { success: true };
}

export async function saveAnnouncement(message: string, adminId: number) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const timestamp = now();
  await db.update(announcements).set({ isActive: false, updatedAt: timestamp });
  await db.insert(announcements).values({ message, isActive: true, createdAt: timestamp, updatedAt: timestamp });
  await db.insert(adminActions).values({ adminUserId: adminId, action: "ADD_ANNOUNCEMENT", metadata: JSON.stringify({ message }), createdAt: timestamp });
  return { success: true };
}
