import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { parse as parseCookieHeader } from "cookie";
import { SignJWT, jwtVerify } from "jose";
import { eq } from "drizzle-orm";
import { users, type User } from "../drizzle/schema";
import { ensureInitialAdminAccount, getDb } from "./db";
import { ENV } from "./_core/env";
import type { Request } from "express";

export const LOCAL_SESSION_COOKIE = "phone_session_id";
const SESSION_MAX_AGE_MS = 1000 * 60 * 60 * 24 * 30;
const SCRYPT_N = 16384;
const SCRYPT_R = 8;
const SCRYPT_P = 1;
const key = () => new TextEncoder().encode(ENV.cookieSecret || "local-development-secret");

export function normalizePhone(phone: string) {
  const compact = phone.trim().replace(/[\s()-]/g, "").replace(/^\+/, "");
  if (compact.startsWith("255")) return `+${compact}`;
  if (/^0\d{9}$/.test(compact)) return `+255${compact.slice(1)}`;
  return compact.startsWith("+") ? compact : `+${compact}`;
}

export function isValidPhone(phone: string) {
  const normalized = normalizePhone(phone);
  return /^\+255(?:61|62|63|67|68|69|70|71|73|75|77|78|79)\d{7}$/.test(normalized);
}

export function hashPassword(password: string) {
  const salt = randomBytes(16);
  const derived = scryptSync(`${password}:${ENV.cookieSecret}`, salt, 64, { N: SCRYPT_N, r: SCRYPT_R, p: SCRYPT_P });
  return `scrypt$${salt.toString("hex")}$${derived.toString("hex")}`;
}

export function verifyPassword(password: string, stored: string | null) {
  if (!stored) return false;
  const [algorithm, saltHex, expectedHex] = stored.split("$");
  if (algorithm !== "scrypt" || !saltHex || !expectedHex) return false;
  const actual = scryptSync(`${password}:${ENV.cookieSecret}`, Buffer.from(saltHex, "hex"), 64, { N: SCRYPT_N, r: SCRYPT_R, p: SCRYPT_P }).toString("hex");
  const expected = Buffer.from(expectedHex, "hex");
  const received = Buffer.from(actual, "hex");
  return expected.length === received.length && timingSafeEqual(expected, received);
}

export async function createLocalSession(user: Pick<User, "id" | "openId" | "name" | "role">) {
  return new SignJWT({ openId: user.openId, name: user.name ?? "", role: user.role })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(String(user.id))
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(key());
}

export async function getLocalUserFromRequest(req: Request): Promise<User | null> {
  const raw = parseCookieHeader(req.headers.cookie ?? "")[LOCAL_SESSION_COOKIE];
  if (!raw) return null;
  try {
    const verified = await jwtVerify(raw, key(), { algorithms: ["HS256"] });
    const id = Number(verified.payload.sub);
    if (!Number.isInteger(id) || id <= 0) return null;
    const db = await getDb();
    if (!db) return null;
    const rows = await db.select().from(users).where(eq(users.id, id)).limit(1);
    const user = rows[0];
    if (!user || user.accountStatus !== "active" || user.verificationStatus === "blocked") return null;
    return user;
  } catch {
    return null;
  }
}

export async function registerLocalUser(input: { firstName: string; lastName: string; phone: string; password: string }) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const phone = normalizePhone(input.phone);
  if (!isValidPhone(phone)) throw new Error("INVALID_PHONE");
  if (input.password.length < 6) throw new Error("WEAK_PASSWORD");
  const existing = await db.select({ id: users.id }).from(users).where(eq(users.phone, phone)).limit(1);
  if (existing.length) throw new Error("PHONE_EXISTS");
  const fullName = [input.firstName, input.lastName].filter(Boolean).join(" ").trim();
  const openId = `local:${phone}`;
  await db.insert(users).values({
    openId,
    name: fullName,
    fullName,
    phone,
    passwordHash: hashPassword(input.password),
    otpCode: null,
    otpExpiresAt: null,
    otpVerified: true,
    loginMethod: "phone",
    role: "user",
    verificationStatus: "pending",
    tokenBalance: 0,
    lastSignedIn: new Date(),
  });
  const created = (await db.select().from(users).where(eq(users.openId, openId)).limit(1))[0];
  if (!created) throw new Error("REGISTRATION_FAILED");
  return { user: created };
}

export async function loginLocalUser(phoneInput: string, password: string) {
  await ensureInitialAdminAccount();
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const phone = normalizePhone(phoneInput);
  const row = (await db.select().from(users).where(eq(users.phone, phone)).limit(1))[0];
  if (!row || !verifyPassword(password, row.passwordHash)) throw new Error("INVALID_CREDENTIALS");
  if (row.accountStatus !== "active" || row.verificationStatus === "blocked") throw new Error(`ACCOUNT_RESTRICTED:${row.restrictionReason ?? "Akaunti haijawezeshwa. Wasiliana na admin."}`);
  await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, row.id));
  const updated = { ...row, lastSignedIn: new Date() };
  return { user: updated, token: await createLocalSession(updated) };
}

export function localSessionMaxAge() {
  return SESSION_MAX_AGE_MS;
}
